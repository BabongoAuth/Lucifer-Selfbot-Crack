Thanks for Downloading Lucifer Crack by Anonymous! Below is a full feature list, and how to set it up. If there are any questions well suffer or ask in our discord if its open

Crack Site: https://lucifersb.xyz/

╦  ╦╦╦═╗╦ ╦╔═╗┌─┐
╚╗╔╝║╠╦╝║ ║╚═╗ ┌┘
 ╚╝ ╩╩╚═╚═╝╚═╝ o 
No. This is a screenshot before the file was encryped, if you do it now, results will be different because of the encryption method.
https://www.virustotal.com/gui/file/fcf7880f9db6fc4104b4476bd9f4f1c61e1102f19fb6e113443bb583382f31bf/detection


╦╔╗╔╔═╗╔╦╗╔═╗╦  ╦  ╦╔╗╔╔═╗  ╔╦╗╦ ╦╔═╗  ╔═╗╔═╗╦  ╔═╗╔╗ ╔═╗╔╦╗
║║║║╚═╗ ║ ╠═╣║  ║  ║║║║║ ╦   ║ ╠═╣║╣   ╚═╗║╣ ║  ╠╣ ╠╩╗║ ║ ║ 
╩╝╚╝╚═╝ ╩ ╩ ╩╩═╝╩═╝╩╝╚╝╚═╝   ╩ ╩ ╩╚═╝  ╚═╝╚═╝╩═╝╚  ╚═╝╚═╝ ╩ 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
1. You downloaded the zip file through the site


╦═╗╔═╗╔═╗╦╔═╗╔╦╗╔═╗╦═╗╦╔╗╔╔═╗  ╦ ╦╔═╗╦ ╦╦═╗  ╔═╗╔═╗╔═╗╔═╗╦ ╦╔╗╔╔╦╗
╠╦╝║╣ ║ ╦║╚═╗ ║ ║╣ ╠╦╝║║║║║ ╦  ╚╦╝║ ║║ ║╠╦╝  ╠═╣║  ║  ║ ║║ ║║║║ ║ 
╩╚═╚═╝╚═╝╩╚═╝ ╩ ╚═╝╩╚═╩╝╚╝╚═╝   ╩ ╚═╝╚═╝╩╚═  ╩ ╩╚═╝╚═╝╚═╝╚═╝╝╚╝ ╩ 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
1. Run the selfbot, let it connect
2. type 2 or register to register your HWID 
3. Enter a username, password, and your key, it should be in your dms from the bot you messaged.

╔═╗╔═╗╔╦╗╔╦╗╦╔╗╔╔═╗  ╦ ╦╔═╗╦ ╦╦═╗  ╔╦╗╔═╗╦╔═╔═╗╔╗╔
║ ╦║╣  ║  ║ ║║║║║ ╦  ╚╦╝║ ║║ ║╠╦╝   ║ ║ ║╠╩╗║╣ ║║║
╚═╝╚═╝ ╩  ╩ ╩╝╚╝╚═╝   ╩ ╚═╝╚═╝╩╚═   ╩ ╚═╝╩ ╩╚═╝╝╚╝
- - - - - - - - - - - - - - - - - - - - - - - - - -
The bot actually gets your token for you, so there is no reason to do the steps below unless the token detection doesnt work. (suprisingly baba does not log the tokens)


How to do it manually:

1. Go to discord
2. Click CTRL, Shift and i at the same time
Once doing this a white or black box at the right side of your discord should pop up.
3. On the top, click the little double arrow at the top, to the right of "Network"
4. In the drop down, click "Application"
5. In the sub category where it says "Storage", click the drop down on "Local Storage"
6. Scroll down all the way in the little table it opens
7. Do control + r
This will restart your discord. We need to get discord to send your token to the auth server again so we can get it and save it so the selfbot can send messages, etc.
8. At the bottom of a table, a new column should appear called "token". Double click into the "Value" column and then copy it. (You will have about five seconds to do this before it dissapears.)

Note: You will need to deactivate 2-Step because if you don't the bot will not be able to send messages, only read them

╔═╗╔═╗╔╗╔╔═╗╦╔═╗╦ ╦╦═╗╦╔╗╔╔═╗  ╔╦╗╦ ╦╔═╗  ╔═╗╔═╗╦  ╔═╗╔╗ ╔═╗╔╦╗
║  ║ ║║║║╠╣ ║║ ╦║ ║╠╦╝║║║║║ ╦   ║ ╠═╣║╣   ╚═╗║╣ ║  ╠╣ ╠╩╗║ ║ ║ 
╚═╝╚═╝╝╚╝╚  ╩╚═╝╚═╝╩╚═╩╝╚╝╚═╝   ╩ ╩ ╩╚═╝  ╚═╝╚═╝╩═╝╚  ╚═╝╚═╝ ╩ 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

┌┬┐ ┌─┐ ┬┌─ ┌─┐ ┌┐┌
 │  │ │ ├┴┐ ├┤  │││
 ┴  └─┘ ┴ ┴ └─┘ ┘└┘
Set it to automatic in the config and change the path to the one you use. pbt, chrome, stable, canary. stable = normal discord/better discord
Put the token you copied from the step above in the config file

┌─┐ ┬─┐ ┌─┐ ┌─┐ ┬ ─┐ ┬
├─┘ ├┬┘ ├┤  ├┤  │ ┌┴┬┘
┴   ┴└─ └─┘ └   ┴ ┴ └─
If you go to the config.json, you are able to set your prefix.
Your prefix is the character you have to type in order for the bot to know you are talking to it.
If your prefix is "-" you will do -help. If your prefix is "." you will do .help

┌─┐ ┌─┐ ┬   ┌─┐ ┬─┐
│   │ │ │   │ │ ├┬┘
└─┘ └─┘ ┴─┘ └─┘ ┴└─
You can set the color to any of the main colors. I can add specific ones on request, but you will have to wait for the next update (never). The default colors are 
Green
Red
Blue
Purple
Pink
Yellow
Orange
Black
White
Gray
Cyan
Turquiose
Maroon
It is case sensitive so make sure you put Green, not GREEN or green.

┬ ┌─┐ ┌─┐ ┌┐┌  ┬ ┬ ┬─┐ ┬  
│ │   │ │ │││  │ │ ├┬┘ │  
┴ └─┘ └─┘ ┘└┘  └─┘ ┴└─ ┴─┘
The icon url is the url to the icon you want to put in the embed. The default one is ghost rider. You can change this by searching google for a gif/picture and then open image in new tab, copy the link url and paste it replacing the old one.

┌─┐ ┌─┐ ┌─┐ ┌┬┐ ┌─┐ ┬─┐
├┤  │ │ │ │  │  ├┤  ├┬┘
└   └─┘ └─┘  ┴  └─┘ ┴└─
The footer is the bottom of what it says at the bottom of all embeds.

┌┐┌┬┌┬┐┬─┐┌─┐  ┌─┐┌┐┌┬┌─┐┌─┐┬─┐
││││ │ ├┬┘│ │  └─┐││││├─┘├┤ ├┬┘
┘└┘┴ ┴ ┴└─└─┘  └─┘┘└┘┴┴  └─┘┴└─
This will automatically redeem any codes sent in dms or a server. In order to have it on, set the value to true, to have it off, set it to false


┌─┐┬┬  ┬┌─┐┬ ┬┌─┐┬ ┬   ┬┌─┐┬┌┐┌┌─┐┬─┐
│ ┬│└┐┌┘├─┤│││├─┤└┬┘   ││ │││││├┤ ├┬┘
└─┘┴ └┘ ┴ ┴└┴┘┴ ┴ ┴   └┘└─┘┴┘└┘└─┘┴└─
This will automatically join any giveaway send by the givaway bot. In order to have it on, set the value to true, to have it off, set it to false

┬ ┬┌─┐┌┐ ┬ ┬┌─┐┌─┐┬┌─┌─┐
│││├┤ ├┴┐├─┤│ ││ │├┴┐└─┐
└┴┘└─┘└─┘┴ ┴└─┘└─┘┴ ┴└─┘
To make a webhook make a channel, then click the channel settings, go to webhooks, create one, copy the link and paste it in the selfbot config.json under what you want the selfbot to log to. For example, I would create a channel for nitro logs, and a webhook for the channel, then paste the link under where it says nitro sniper webhook link.

╔═╗╦═╗╦═╗╔═╗╦═╗╔═╗┌─┐
║╣ ╠╦╝╠╦╝║ ║╠╦╝╚═╗ ┌┘
╚═╝╩╚═╩╚═╚═╝╩╚═╚═╝ o 

If you are getting errors, like the bot not launching, please turn off your anti virus, and then try again.


# This is where you can make custom scripts with the discord api wrapper in python. You can do events, as well as commands
import discord # this is the library you will be using, so make sure you have it installed
import sys, os, time # a few extra imports to get time and some system functions ect

@Lucifer.command(pass_context=True) # We use Lucifer as the bot name, so it will be @Lucifer.command or @Lucifer.event
async def testscript(ctx): # .testscript is the command you will use to call this function
	print("Hello this is a custom commands test from Lucifer Selfbot!") # this will print something in the console
	await ctx.send("Everything is working!") # This is to send a message in the same channel you did the command in

@Lucifer.command(pass_context=True)
async def testuser(ctx, user : discord.Member): # testuser @user is the command you will use to call this function
	cuminsidepls = 2 + 7 # doing some basic math
	await ctx.send(f"{user.mention} likes men! and 2 + 7 is {str(cuminsidepls)}") # and sending it all together

# Now you try to code some of your custom scripts and show us what you come up with!